public interface Iprint
{
    public void printAttack(String injurerName, String victimName, int ATN, int HP);
    public void printWin(String name);
}
